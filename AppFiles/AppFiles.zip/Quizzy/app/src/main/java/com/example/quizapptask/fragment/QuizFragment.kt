package com.example.quizapptask.fragment

import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.quizapptask.R
import com.example.quizapptask.api.RetrofitInstance
import com.example.quizapptask.databinding.FragmentQuizBinding
import retrofit2.HttpException
import java.io.IOException

class QuizFragment : Fragment() {
    private lateinit var binding: FragmentQuizBinding
    private var mCurrentQuestion: Int = 1
    private val mQuestionList = arrayListOf<String>()
    private val mOptionList = arrayListOf<ArrayList<String>>()
    private val mAnswerList = arrayListOf<String>()
    private var mSelectedOption: Int = 0
    private var mCorrectAnswer: Int = 0
    private val mapCategoryToCode = mapOf(
        "General Knowledge" to 9,
        "Mathematics" to 19,
        "Sports" to 21,
        "History" to 23,
        "Animals" to 27
    )
    private val options = ArrayList<TextView>()
    private val myArgs: QuizFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentQuizBinding.inflate(layoutInflater, container, false)

        options.apply {
            add(binding.tvOption1)
            add(binding.tvOption2)
            add(binding.tvOption3)
            add(binding.tvOption4)
        }

        setupOptionClickListeners()
        fetchQuestions()
        setupDoneButton()

        return binding.root
    }

    private fun setupOptionClickListeners() {
        options.forEachIndexed { index, option ->
            option.setOnClickListener {
                if (binding.btDone.text != "Finish" && binding.btDone.text != "Next") {
                    defaultOptionView()
                    it.background = ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.selected_option
                    )
                    mSelectedOption = index + 1
                }
            }
        }
    }

    private fun fetchQuestions() {
        lifecycleScope.launchWhenCreated {
            val response = try {
                val url = "/api.php?amount=10&category=" +
                        mapCategoryToCode[myArgs.category].toString() +
                        "&difficulty=" + myArgs.difficulty + "&type=multiple"
                Log.d("url", url)
                RetrofitInstance.api.getQuestions(url)
            } catch (e: IOException) {
                Log.e("QuizFragment", "IOException, you might not have internet connection")
                return@launchWhenCreated
            } catch (e: HttpException) {
                Log.e("QuizFragment", "HttpException, unexpected response")
                return@launchWhenCreated
            }

            response.body()?.results?.forEach { item ->
                mQuestionList.add(item.question)
                mAnswerList.add(item.correct_answer)

                val optionList = arrayListOf<String>().apply {
                    add(item.correct_answer)
                    addAll(item.incorrect_answers)
                }

                optionList.shuffle()
                mOptionList.add(optionList)
            }

            binding.progressBar.visibility = View.INVISIBLE
            binding.tvFetchingQuestions.visibility = View.INVISIBLE
            binding.btDone.visibility = View.VISIBLE
            binding.linearLayoutOptions.visibility = View.VISIBLE
            binding.tvQuestions.visibility = View.VISIBLE
            binding.llProgressDetails.visibility = View.VISIBLE

            setQuestion()
        }
    }

    private fun setupDoneButton() {
        binding.btDone.setOnClickListener {
            if (mSelectedOption == 0) {
                Toast.makeText(context, "Please select an option", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            when (binding.btDone.text) {
                "Submit" -> {
                    checkAnswer()
                    binding.btDone.text = "Next"
                }
                "Next" -> {
                    mSelectedOption = 0
                    setQuestion()
                }
                "Submit & Finish" -> {
                    checkAnswer()
                    val action = QuizFragmentDirections.actionQuizFragmentToResultFragment(myargs = mCorrectAnswer)
                    findNavController().navigate(action)
                }
            }
        }
    }

    private fun setQuestion() {
        defaultOptionView()

        if (mCurrentQuestion > mQuestionList.size) return

        binding.tvQuestions.text = mQuestionList[mCurrentQuestion - 1]
        val options = mOptionList[mCurrentQuestion - 1]
        binding.tvOption1.text = options[0]
        binding.tvOption2.text = options[1]
        binding.tvOption3.text = options[2]
        binding.tvOption4.text = options[3]

        binding.progressBarQuestions.progress = mCurrentQuestion
        binding.tvProgress.text = "$mCurrentQuestion/10"

        if (mCurrentQuestion == mQuestionList.size) {
            binding.btDone.text = "Submit & Finish"
        } else {
            binding.btDone.text = "Submit"
        }
    }

    private fun checkAnswer() {
        val correctAnswer = mAnswerList[mCurrentQuestion - 1]
        val selectedAnswer = mOptionList[mCurrentQuestion - 1][mSelectedOption - 1]

        if (selectedAnswer == correctAnswer) {
            mCorrectAnswer++
            answerView(mSelectedOption, R.drawable.correct_option)
        } else {
            val correctOptionIndex = mOptionList[mCurrentQuestion - 1].indexOf(correctAnswer) + 1
            answerView(correctOptionIndex, R.drawable.correct_option)
            answerView(mSelectedOption, R.drawable.incorrect_option)
        }

        mCurrentQuestion++
    }

    private fun defaultOptionView() {
        options.forEach { option ->
            option.background = ContextCompat.getDrawable(requireContext(), R.drawable.cardview)
        }
        mSelectedOption = 0
    }

    private fun answerView(answer: Int, drawableView: Int) {
        options[answer - 1].background = ContextCompat.getDrawable(requireContext(), drawableView)
    }
}
